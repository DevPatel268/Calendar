from django.contrib import admin
from cal.models import Event

admin.site.register(Event)